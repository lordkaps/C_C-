#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#define LINHAS 2

char nome[10][41];
char endereco[10][41];
char cep[10][9];
char bairro[10][41];
char telefone[10][12];

void imprimir_dados(int linha)
{

    printf("%s", nome[linha]);
    printf(" - ");
    printf("%s", endereco[linha]);
    printf(" - ");
    printf("%s", cep[linha]);
    printf(" - ");
    printf("%s", bairro[linha]);
    printf(" - ");
    printf("%s", telefone[linha]);
    printf("\n");
}

void preencher_dados()
{
    for (int linha = 0; linha < LINHAS; linha++)
    {
        printf("Nome : ");
        gets(nome[linha]);
        printf("\n");
        printf("Endereco : ");
        gets(endereco[linha]);
        printf("\n");
        printf("cep : ");
        gets(cep[linha]);
        printf("\n");
        printf("bairro : ");
        gets(bairro[linha]);
        printf("\n");
        printf("telefone : ");
        gets(telefone[linha]);
        printf("\n");
    }
}

void buscar_nome()
{
    int achou = 0;
    char nome_busca[41];
    printf("Digite o nome para buscar :");
    gets(nome_busca);
    printf("\n");

    for (int linha = 0; linha < LINHAS; linha++)
    {

        if (strcmp(nome_busca, nome[linha]) == 0)
        {
            imprimir_dados(linha);
            achou = 1;
        }
    }

    if (!achou)
    {
        printf("Nao achou\n");
    }
}

int main()
{

    preencher_dados();

    printf("\n");
    system("pause");

    buscar_nome();
    
    /*
    for(int linha = 0 ; linha < LINHAS; linha++){
        imprimir_dados(linha);
    } */
}