void abertura1();
void questao1();

void abertura2();
void recebevalor2();
void calculo1();
void calculo2();
void calculo3();
void questao2();

void abertura3();
void questao3();

void abertura4();
void recebevalor4();
void contador();
void posicao();
void questao4();

void abertura5();
void valormatriz();
void calcdeterminante();
void questao5();