#ifndef _PROGRAMA_
#define _PROGRAMA
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string.h>

void calculaidade();
void calculoemprestimo();
void coroacircular();

#endif