#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <math.h>
#include <Windows.h>

void preencher_vetor_inteiros(int vetor[5]);
void preencher_vetor_double(double vetor[5]);
double calculo_net(int vetor_x[5], double vetor_w[5]);
void mostra_resultado(double numero, int vetor[5]);